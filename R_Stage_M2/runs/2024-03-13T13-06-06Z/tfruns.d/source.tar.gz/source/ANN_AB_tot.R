
# LIMITE : qualit� des donn�es inputs, desequilibre des os

# Libraries
# install.packages("keras","tensorflow")
library(keras)
library(mlbench) 
library(dplyr)
library(magrittr)
library(neuralnet)
library(ggplot2)
library(reshape2)
library(tfruns)


# Data
AB_tot_train = read.csv2("C:/Users/diall/OneDrive/Bureau/M2_MODE/stage_abdou_m2/R_Stage_M2/datas/AB_tot_train.csv")
AB_tot_test = read.csv2("C:/Users/diall/OneDrive/Bureau/M2_MODE/stage_abdou_m2/R_Stage_M2/datas/AB_tot_test.csv")

data = rbind(AB_tot_train,AB_tot_test)

AB_tot_train %<>% mutate_if(is.factor, as.numeric)
AB_tot_test %<>% mutate_if(is.factor, as.numeric)

AB_tot_train <- as.matrix(AB_tot_train)
dimnames(AB_tot_train) <- NULL

AB_tot_test <- as.matrix(AB_tot_test)
dimnames(AB_tot_test) <- NULL


training <- AB_tot_train[,-1]
training <- as.matrix(training)

test <- AB_tot_test[,-1]
test <- as.matrix(test)

trainingtarget <- AB_tot_train[,1]
testtarget <- AB_tot_test[,1]
testtarget <- as.matrix(testtarget)






# Matrix
data %<>% mutate_if(is.factor, as.numeric)
data <- as.matrix(data)
dimnames(data) <- NULL

# Partition
set.seed(1234)
ind <- sample(2, nrow(data), replace = T, prob = c(.7, .3))
training <- data[ind==1,2:26]
test <- data[ind==2, 2:26]
trainingtarget <- data[ind==1, 1]
testtarget <- data[ind==2, 1]





# Distribution de toute les variables 
data_long <- melt(data)

ggplot(data_long, aes(x=value)) +
  geom_histogram(bins=20) +
  facet_wrap(~variable, scales="free") +
  theme_gray() +
  theme(plot.title = element_text(hjust = 0.5)) +
  labs(title="Histogramme", x="Valeur", y="Fr�quence")



# Distribution de var rep
par(mfrow=c(1,2))
df <- data.frame(y =trainingtarget)
abundance_dist_train = ggplot(df, aes(x=y)) +
  geom_histogram(aes(y=..density..), fill="#69b3a2", color="#e9ecef", bins=30, alpha=2) +
  geom_density(fill="black", alpha=0.2) +
  theme_gray() +
  labs(title="Train: Histogram and Density Graph", x="Value", y="Density") +
  theme(plot.title = element_text(hjust = 0.5))
ggsave("Results/abundance_dist_train.png", plot = abundance_dist_train, dpi = 300)

df <- data.frame(y =testtarget)
abundance_dist_test = ggplot(df, aes(x=y)) +
  geom_histogram(aes(y=..density..), fill="#69b3a2", color="#e9ecef", bins=30, alpha=2) +
  geom_density(fill="black", alpha=0.2) +
  theme_gray() +
  labs(title="Test: Histogram and Density Graph", x="Value", y="Density") +
  theme(plot.title = element_text(hjust = 0.5))
ggsave("Results/abundance_dist_test.png", plot = abundance_dist_test, dpi = 300)

abundance_dist_train
abundance_dist_test


# Distrvitbution de var rep dans train et de test: est ce homogene ?
df_train <- data.frame(y = trainingtarget, set = "Training set")
df_test <- data.frame(y = testtarget, set = "Test set")

df <- rbind(df_train, df_test)

abundance_dist_train_and_test= ggplot(df, aes(x=y, fill=set)) +
  geom_histogram(aes(y=..density..), bins=200, alpha=0.75, position="identity") +
  scale_fill_manual(values=c("Training set"="#F8766D", "Test set"="#00BFC4")) +
  labs(title="Distribution of training and test data",
       x="Abundance",
       y="Density",
       fill="Set") +
  theme_gray() +
  theme(plot.title = element_text(hjust = 0.5))
ggsave("Results/abundance_dist_train_and_test.png", plot = abundance_dist_train_and_test, dpi = 300)
abundance_dist_train_and_test






data %<>% mutate_if(is.factor, as.numeric)

# for (i in names(data)){
#   cat( paste0(i, '+'))
# }
# Neural Network Visualization
n <- neuralnet( AB_tot~ CaCO3+gps_x+bio7+bio4+N+bio3+CN+gps_y+elevation+P+bio15+bio18+
                 silt+gdd0+clay+sand+bio6+PET+cmi_mean+clcm_lvl3mf+clcm_lvl3gua+
                 clcm_lvl3ng+clcm_lvl3nial+clcm_lvl3p+clcm_lvl3v,
               data = data,
               hidden = c(10,5),
               linear.output = F,
               lifesign = 'full',
               rep=1)
abundance_ANN = plot(n,
     col.hidden = 'darkgreen',
     col.hidden.synapse = 'darkgreen',
     show.weights = F,
     information = F,
     fill = 'lightblue')
ggsave("Results/abundance_ANN.png", plot = abundance_ANN, dpi = 300)



# Normalize
m <- colMeans(training)
s <- apply(training, 2, sd)
training <- scale(training, center = m, scale = s)
test <- scale(test, center = m, scale = s)






# Create Model : ANN_1 ----------------------------------------------------
ANN_1 <- keras_model_sequential()
ANN_1 %>% 
  layer_dense(units = 5, activation = 'relu', input_shape = c(25)) %>%
  layer_dense(units = 1)

# Compile
ANN_1 %>% compile(loss = 'mse',
                  optimizer = 'rmsprop',
                  metrics = 'mae')
summary(ANN_1)

# Fit ANN_1
myANN_1 <- ANN_1 %>%
  fit(training,
      trainingtarget,
      epochs = 100,
      #batch_size = 1,
      validation_split = 0.2)
plot(myANN_1)

# Evaluate
ANN_1 %>% evaluate(test, testtarget)
ANN_1_pred <- ANN_1 %>% predict(test)
ANN_1_mse = mean((testtarget-ANN_1_pred)^2) # loss -> mse
ANN_1_mae =mean(abs(ANN_1_pred - testtarget),na.rm=TRUE) # MAE 
ANN_1_rmse =sqrt(mean((testtarget - ANN_1_pred)^2,na.rm=TRUE)) # rmse
SSR <- sum((ANN_1_pred - testtarget) ^ 2,na.rm=TRUE)
SST <- sum((testtarget - mean(testtarget)) ^ 2)
ANN_1_rsquare = 1 - (SSR / SST) # r_adj <- 
ANN_1_plot_cor = plot(testtarget, ANN_1_pred,main="ANN_1")
ANN_1_cor = cor(testtarget,ANN_1_pred)^2
ANN_1_results = data.frame(model = "ANN_1",mse = ANN_1_mse, mae = ANN_1_mae,
                            rmse = ANN_1_rmse, r_square =ANN_1_rsquare, cor_pred_obs= ANN_1_cor)
ANN_1_results





# Hyperparameter tuning ---------------------------------------------------


runs <- tuning_run("Experiment.R",
                   flags = list(dense_units1 = c(32, 64),
                                dense_units2 = c(16, 32),
                                dropout1 = c(0.1, 0.2),
                                dropout1 = c(0.1, 0.2),
                                batch_size = c(32, 64)))

# Best hyperparameter values
head(runs)
results <- runs[,c(5,6)]






# Create Model : ANN_2 ----------------------------------------------------
ANN_2 <- keras_model_sequential()
ANN_2 %>% 
  layer_dense(units = 10, activation = 'relu', input_shape = c(25)) %>%
  layer_dense(units = 5, activation = 'relu') %>%
  layer_dense(units = 1)

summary(ANN_2)
# Compile
ANN_2 %>% compile(loss = 'mse',
                  optimizer = 'rmsprop',
                  metrics = 'mae')
summary(ANN_2)


# Fit ANN_2
myANN_2 <- ANN_2 %>%
  fit(training,
      trainingtarget,
      epochs = 100,
      batch_size = 32,
      validation_split = 0.2)
plot(myANN_2)

# Evaluate
ANN_2 %>% evaluate(test, testtarget)
ANN_2_pred <- ANN_2 %>% predict(test)
ANN_2_mse = mean((testtarget-ANN_2_pred)^2) # loss -> mse
ANN_2_mae =mean(abs(ANN_2_pred - testtarget),na.rm=TRUE) # MAE 
ANN_2_rmse =sqrt(mean((testtarget - ANN_2_pred)^2,na.rm=TRUE)) # rmse
SSR <- sum((ANN_2_pred - testtarget) ^ 2,na.rm=TRUE)
SST <- sum((testtarget - mean(testtarget)) ^ 2)
ANN_2_rsquare = 1 - (SSR / SST) # r_adj <- 
ANN_2_plot_cor = plot(testtarget, ANN_2_pred, main = "ANN_2")
ANN_2_cor = cor(testtarget,ANN_2_pred)^2
ANN_2_results = data.frame(model = "ANN_2",mse = ANN_2_mse, mae = ANN_2_mae,
                           rmse = ANN_2_rmse, r_square =ANN_2_rsquare, cor_pred_obs= ANN_2_cor)
rbind(ANN_1_results,ANN_2_results)






# Create Model : ANN_3 ----------------------------------------------------

ANN_3 <- keras_model_sequential()
ANN_3 %>% 
  layer_dense(units = 10, activation = 'relu', input_shape = c(25)) %>%
  layer_dropout(rate = 0.4)  %>%
  layer_dense(units = 10, activation = 'relu') %>%
  layer_dropout(rate = 0.3)  %>%
  layer_dense(units = 10, activation = 'relu') %>%
  layer_dropout(rate = 0.2)  %>%
  layer_dense(units = 5, activation = 'relu') %>%
  layer_dropout(rate = 0.1)  %>%
  layer_dense(units = 1)

summary(ANN_3)
# Compile
ANN_3 %>% compile(loss = 'mse',
                  optimizer = 'rmsprop',
                  metrics = 'mae')
summary(ANN_3)

# Fit ANN_3
myANN_3 <- ANN_3 %>%
  fit(training,
      trainingtarget,
      epochs = 100,
      batch_size = 32,
      validation_split = 0.2)
plot(myANN_3)

# Evaluate
ANN_3 %>% evaluate(test, testtarget)
ANN_3_pred <- ANN_3 %>% predict(test)
ANN_3_mse = mean((testtarget-ANN_3_pred)^2) # loss -> mse
ANN_3_mae =mean(abs(ANN_3_pred - testtarget),na.rm=TRUE) # MAE 
ANN_3_rmse =sqrt(mean((testtarget - ANN_3_pred)^2,na.rm=TRUE)) # rmse
SSR <- sum((ANN_3_pred - testtarget) ^ 2,na.rm=TRUE)
SST <- sum((testtarget - mean(testtarget)) ^ 2)
ANN_3_rsquare = 1 - (SSR / SST) # r_adj <- 
ANN_3_plot_cor = plot(testtarget, ANN_3_pred, main = "ANN_3")
ANN_3_cor = cor(testtarget,ANN_3_pred)^2
ANN_3_results = data.frame(model = "ANN_3",mse = ANN_3_mse, mae = ANN_3_mae,
                           rmse = ANN_3_rmse, r_square =ANN_3_rsquare, cor_pred_obs= ANN_3_cor)
rbind(ANN_1_results,ANN_2_results,ANN_3_results)




# modif 4 : optimizer = optimizer_rmsprop(learning_rate = 0.001)
ANN_4 <- keras_model_sequential()
ANN_4 %>% 
  layer_dense(units = 100, activation = 'relu', input_shape = c(25)) %>%
  layer_dropout(rate = 0.4)  %>%
  layer_dense(units = 50, activation = 'relu') %>%
  layer_dropout(rate = 0.3)  %>%
  layer_dense(units = 20, activation = 'relu') %>%
  layer_dropout(rate = 0.2)  %>%
  layer_dense(units = 1)

summary(ANN_4)
# Compile
ANN_4 %>% compile(loss = 'mse',
                  optimizer = optimizer_rmsprop(learning_rate = 0.002),
                  metrics = 'mae')
summary(ANN_4)

# Fit ANN_4
myANN_4 <- ANN_4 %>%
  fit(training,
      trainingtarget,
      epochs = 100,
      batch_size = 32,
      validation_split = 0.2)
plot(myANN_4)

# Evaluate
ANN_4 %>% evaluate(test, testtarget)
ANN_4_pred <- ANN_4 %>% predict(test)
ANN_4_mse = mean((testtarget-ANN_4_pred)^2) # loss -> mse
ANN_4_mae =mean(abs(ANN_4_pred - testtarget),na.rm=TRUE) # MAE 
ANN_4_rmse =sqrt(mean((testtarget - ANN_4_pred)^2,na.rm=TRUE)) # rmse
SSR <- sum((ANN_4_pred - testtarget) ^ 2,na.rm=TRUE)
SST <- sum((testtarget - mean(testtarget)) ^ 2)
ANN_4_rsquare = 1 - (SSR / SST) # r_adj <- 
ANN_4_plot_cor = plot(testtarget, ANN_4_pred, main = "ANN_4")
ANN_4_cor = cor(testtarget,ANN_4_pred)^2
ANN_4_results = data.frame(model = "ANN_4",mse = ANN_4_mse, mae = ANN_4_mae,
                           rmse = ANN_4_rmse, r_square =ANN_4_rsquare, cor_pred_obs= ANN_4_cor)
rbind(ANN_1_results,ANN_2_results,ANN_3_results,ANN_4_results)
